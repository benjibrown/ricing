# Install Decay Theme
# Made by Lamp
# Don't steal ples

mv decay ~/.config/openbox-themes/themes
mv gtk ~/.local/share/themes/decay
mv Decay-Dark ~/.local/share/icons/Decay-Dark
