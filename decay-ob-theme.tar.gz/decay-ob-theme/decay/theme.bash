# ------------------------------------------------------------------------------
# Copyright (C) 2020-2022 Aditya Shakya <adi1090x@gmail.com>
#
# Everforest Theme
# ------------------------------------------------------------------------------

# Colors
background='#14141e'
foreground='#c6a0f6'
color0='#1c1f29'
color1='#e5646a'
color2='#94F7C5'
color3='#f6d48f'
color4='#75aaf0'
color5='#cb8ff3'
color6='#79c3ee'
color7='#e3e6eb'
color8='#1c1f29'
color9='#e5646a'
color10='#94F7C5'
color11='#f6d48f'
color12='#75aaf0'
color13='#cb8ff3'
color14='#79c3ee'
color15='#e3e6eb'

accent='#c6a0f6'
light_value='0.05'
dark_value='0.30'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='JetBrains Mono:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Zafiro'

# Terminal
terminal_font_name='JetBrainsMono Nerd Font'
terminal_font_size='10'

# Geany
geany_colors='manhattan.conf'
geany_font='JetBrains Mono 10'

# Appearance
gtk_font='Noto Sans 9'
gtk_theme='decay'
icon_theme='Decay-Papirus'
cursor_theme='Qogirr-Dark'

# Openbox
ob_theme='decay'
ob_layout='NLIMC'
ob_font='JetBrains Mono'
ob_font_size='9'
ob_menu='menu-icons.xml'
ob_margin_t='78'
ob_margin_b='20'
ob_margin_l='20'
ob_margin_r='20'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x78'
dunst_origin='top-right'
dunst_font='JetBrains Mono 10'
dunst_border='0'
dunst_separator='2'

# Plank
plank_hmode='intelligent'
plank_offset='0'
plank_position='bottom'
plank_theme='Transparent'
plank_icon_size='32'
plank_zoom_percent='120'

# Picom
picom_backend='glx'
picom_corner='12'
picom_shadow_r='14'
picom_shadow_o='0.30'
picom_shadow_x='-12'
picom_shadow_y='-12'
picom_blur_method='none'
picom_blur_strength='0'
