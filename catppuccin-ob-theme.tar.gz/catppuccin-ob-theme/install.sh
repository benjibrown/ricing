# Theme created by Lamp
# Copyright!

mv catppuccin ~/.config/openbox-themes/themes
mv gtk ~/.local/share/themes/catppuccin
mv icons ~/.local/share/icons/Catppuccin
