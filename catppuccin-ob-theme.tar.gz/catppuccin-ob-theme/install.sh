# Theme created by Lamp
# Copyright!

mv catppuccin ~/.config/openbox-themes/themes
sudo mv gtk /usr/share/themes/catppuccin
sudo mv icons /usr/share/icons/Catppuccin
