# Made by Lamp
# Copyright!

mv Dracula ~/.config/openbox-themes/themes/
